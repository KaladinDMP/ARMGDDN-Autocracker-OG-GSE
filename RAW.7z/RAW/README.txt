v1.0.1 - Changed all exe files that were created from bats to exe to change the version number and changed the script to ARMGDDN.Main, ARMGDDN.Cold.Client, and ARMGDDN.Autocracker to fix the issues with the appid never reaching fallback and moving steam_appid.txts with old app id's in them. Also changed the clears and pauses a bit to make the flow a bit smoother and easier to read. Also changed the install and removal of the context menu reg edits to warn about the talking so that people can adjust the volume if they want. RAW files updated, steamclient files in Api removed since they arent used.


v1.0.0 - This is the originals that later became the exes so you can more easily see the code without messing with the exes. 
For the bats i used Advanced Bat To Exe Converter Pro v2.93 and for the Python scripts i used PyInstaller and Auto-Py-To-Exe

KaladinDMP