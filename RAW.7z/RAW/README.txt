This is the originals that later became the exes so you can more easily see the code without messing with the exes. 
For the bats i used Advanced Bat To Exe Converter Pro v2.93 and for the Python scripts i used PyInstaller and Auto-Py-To-Exe

KaladinDMP